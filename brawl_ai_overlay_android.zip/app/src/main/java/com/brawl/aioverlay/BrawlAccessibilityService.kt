package com.brawl.aioverlay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

class BrawlAccessibilityService : AccessibilityService() {

    companion object {
        var instance: BrawlAccessibilityService? = null
    }

    private var windowManager: WindowManager? = null
    private var floatingView: LinearLayout? = null
    private var aiDirectControlEnabled = true

    // 사용자 상단 조이스틱 방향 벡터
    private var userCmdX = 0f
    private var userCmdY = 0f

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun startFloatingOverlay(resultCode: Int, projectionData: Intent) {
        if (floatingView != null) return

        val params = WindowManager.LayoutParams(
            440,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 24
        }

        val bg = GradientDrawable().apply {
            setColor(Color.parseColor("#DD0F172A"))
            cornerRadius = 36f
            setStroke(2, Color.parseColor("#38BDF8"))
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding(28, 24, 28, 24)
        }

        val header = TextView(this).apply {
            text = "● BRAWL AI OVERLAY (좌측 상단)"
            textSize = 12f
            setTextColor(Color.parseColor("#38BDF8"))
        }

        val btnToggle = Button(this).apply {
            text = "직접 조종: ON (터치 시 멈춤)"
            setBackgroundColor(Color.parseColor("#10B981"))
            setTextColor(Color.BLACK)
            setOnClickListener {
                aiDirectControlEnabled = !aiDirectControlEnabled
                if (aiDirectControlEnabled) {
                    text = "직접 조종: ON (터치 시 멈춤)"
                    setBackgroundColor(Color.parseColor("#10B981"))
                } else {
                    text = "직접 조종: OFF (수동 조작 모드)"
                    setBackgroundColor(Color.parseColor("#475569"))
                }
            }
        }

        val stickPad = TextView(this).apply {
            text = "[ 무빙 방향 지시 조이스틱 ]\n여기를 드래그해 이동 방향 지시"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(16, 36, 16, 36)
            setBackgroundColor(Color.parseColor("#1E293B"))
            setOnTouchListener { v, ev ->
                val cx = v.width / 2f
                val cy = v.height / 2f
                when (ev.action) {
                    MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                        val dx = ev.x - cx
                        val dy = ev.y - cy
                        val d = hypot(dx, dy).coerceAtLeast(1f)
                        userCmdX = (dx / d).coerceIn(-1f, 1f)
                        userCmdY = (dy / d).coerceIn(-1f, 1f)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        userCmdX = 0f
                        userCmdY = 0f
                    }
                }
                true
            }
        }

        container.addView(header)
        container.addView(btnToggle)
        container.addView(stickPad)

        floatingView = container
        windowManager?.addView(floatingView, params)
    }

    // 실제 브롤스타즈 좌측 무빙 패드 & 우측 에임 패드에 멀티터치 제스처 주입
    fun dispatchDualPadControl(
        leftPadX: Float, leftPadY: Float, moveVecX: Float, moveVecY: Float,
        rightPadX: Float, rightPadY: Float, aimVecX: Float, aimVecY: Float,
        shouldFire: Boolean
    ) {
        if (!aiDirectControlEnabled) return
        val radius = 110f
        val builder = GestureDescription.Builder()

        val movePath = Path().apply {
            moveTo(leftPadX, leftPadY)
            lineTo(leftPadX + moveVecX * radius, leftPadY + moveVecY * radius)
        }
        builder.addStroke(GestureDescription.StrokeDescription(movePath, 0L, 60L, true))

        if (shouldFire) {
            val aimPath = Path().apply {
                moveTo(rightPadX, rightPadY)
                lineTo(rightPadX + aimVecX * radius, rightPadY + aimVecY * radius)
            }
            builder.addStroke(GestureDescription.StrokeDescription(aimPath, 0L, 50L, false))
        }
        dispatchGesture(builder.build(), null, null)
    }
}
