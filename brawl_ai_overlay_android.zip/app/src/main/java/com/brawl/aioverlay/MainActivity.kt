package com.brawl.aioverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val REQ_OVERLAY = 1001
    private val REQ_MEDIA_PROJECTION = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0B1120"))
            setPadding(64, 64, 64, 64)
        }

        val title = TextView(this).apply {
            text = "BRAWL AI OVERLAY 런처"
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 24)
        }

        val desc = TextView(this).apply {
            text = "1단계: [다른 앱 위에 표시 권한] 허용\n2단계: [접근성 서비스]에서 'Brawl AI 패드 자동 조종 서비스' 켜기\n3단계: [왼쪽 위 오버레이 시작] 클릭 후 브롤스타즈 실행"
            textSize = 14f
            setTextColor(Color.parseColor("#94A3B8"))
            setPadding(0, 0, 0, 40)
        }

        val btnOverlayPerm = Button(this).apply {
            text = "1. 다른 앱 위에 표시 권한 허용"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivityForResult(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                        REQ_OVERLAY
                    )
                } else {
                    Toast.makeText(context, "이미 허용되어 있습니다.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val btnAccessPerm = Button(this).apply {
            text = "2. 접근성 서비스(패드 터치 조종) 켜기"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val btnStart = Button(this).apply {
            text = "3. 화면 인식 권한 허용 & 왼쪽 위 오버레이 띄우기"
            setBackgroundColor(Color.parseColor("#10B981"))
            setTextColor(Color.BLACK)
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(context, "먼저 1번 '다른 앱 위에 표시' 권한을 허용해주세요!", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mpm.createScreenCaptureIntent(), REQ_MEDIA_PROJECTION)
            }
        }

        root.addView(title)
        root.addView(desc)
        root.addView(btnOverlayPerm)
        root.addView(btnAccessPerm)
        root.addView(btnStart)
        setContentView(root)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_MEDIA_PROJECTION && resultCode == RESULT_OK && data != null) {
            BrawlAccessibilityService.instance?.startFloatingOverlay(resultCode, data)
            Toast.makeText(this, "왼쪽 위 오버레이 실행됨! 이제 브롤스타즈를 켜세요.", Toast.LENGTH_LONG).show()
            finish()
        }
    }
}
